import SculptGL from './src/SculptGL';

window.SculptGL = SculptGL;

export default SculptGL;
