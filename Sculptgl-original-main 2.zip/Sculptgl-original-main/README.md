Status
======

I don't maintain Sculptgl anymore (except small/minor fixes).

SculptGL - WebGL sculpting
==========================

You can try it [**here**](http://stephaneginier.com/sculptgl).

Additional information can be found on the [website](http://stephaneginier.com/).

Tools
=====

Nodejs needs to be installed [nodejs](http://nodejs.org/).

Then for the browser build :
```
yarn # npm install
yarn dev # npm run dev (npm run release for final build, npm run website should not be used)
// visit app/index.html
```

GitHub Pages build (required for the hosted site):
```
npm install
npm run github
// deploy docs/ via GitHub Pages (Actions workflow builds and publishes)
```

For standalone :
```
yarn add electron
yarn add electron-packager
yarn standalone
```

Credits
=======

#### Environments

The raw environments are from https://hdrihaven.com/hdris
